HEdit v2.1
Copyright (C) 1992-1998 Yuri Software
All Rights Reserved


SUMMARY

Hexadecimal editor for binary files. Syncronized hex/text cursors, 
unlimited file size (easily works with GB-sized files), insert and 
delete, binary and text search, auto text/binary sensing, decimal 
display for byte, short, int, long, float, and double. Integrates with 
the Windows 95 or NT 4.0 shell.


REQUIREMENTS

Requires Microsoft Windows 95 or Windows NT running on Intel platform.


INSTALLATION

If you obtained HEdit on an electronic media, execute the main archive 
file HEDIT21.EXE and follow the instructions on screen.

If you obtained HEdit on a floppy disk, execute the SETUP.EXE file and 
follow the instructions on screen.

